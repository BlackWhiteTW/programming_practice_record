#include <stdio.h>

int main() {
    int m = 0, n =0 , p = 0, k = 0, i, j;

    // 讀取a矩陣的維度和元素
    scanf("%d,%d", &m, &n);
    int a[m][n];
    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {
            a[i][j]=0;
            scanf("%d", &a[i][j]);
        }
    }

    // 讀取b矩陣的維度和元素
    scanf("%d,%d", &n, &p);
    int b[n][p];
    for (i = 0; i < n; i++) {
        for (j = 0; j < p; j++) {
            b[i][j]=0;
            scanf("%d", &b[i][j]);
        }
    }

    // 初始化c矩陣
    int c[m][p];
    for (i = 0; i < m; i++) {
        for (j = 0; j < p; j++) {
            c[i][j] = 0;
        }
    }
    
    // 矩陣相乘
    for (i = 0; i < m; i++) {
        for (j = 0; j < p; j++) {
            for (k = 0; k < n; k++) {
                c[i][j] += a[i][k] * b[k][j];
            }
            printf("%d ", c[i][j]);
        }
    }

    return 0;
}
