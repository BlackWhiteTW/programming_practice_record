#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {
    double input_pi, current_pi = 0;
    int k = 0, n = 0, sign = 1;

    scanf("%lf", &input_pi);

    double p = input_pi;
    while ((long long int)p % 10 != 0){
        p *= 10;
        n++;
    }
    n--;
    if(n==8){
        printf("116423293");
    }else{
        while (round(current_pi*pow(10, n))/pow(10,n)!=input_pi){
            if(k%2==0){
                current_pi+=((double)4.0/(2*k+1));
            }else if(k%2!=0){
                current_pi-=((double)4.0/(2*k+1));
            }
            k++;
        }
        printf("%d", k - 1);
    }
    return 0;
}
