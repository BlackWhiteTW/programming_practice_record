#include <stdio.h>
#include <string.h>

int main() {
    int a[2][500]={{0},{0}}, i=0, ele=0;
    char check = ' ';

    while (scanf("%d%c", &a[0][ele], &check) && check==' '){
        ele++;
    }
    while (i <= ele){
        scanf("%d", &a[1][i]);
        i++;
    }

    int j, sum=0;
    for (j = 0; j<=ele; j++){
        sum += a[0][j]*a[1][ele-j];
    }
    printf("%d",sum);
    return 0;
}
