#include <stdio.h>

int main() {
    int m, n, i, j;
    int a[100][100], aT[100][100];

    // 讀取矩陣a的維度和元素
    scanf("%d,%d", &m, &n);
    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &a[i][j]);
        }
    }

    // 轉置矩陣
    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {
            aT[j][i] = a[i][j];
        }
    }

    // 輸出轉置矩陣aT
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            printf("%d ", aT[i][j]);
        }
    }

    return 0;
}
