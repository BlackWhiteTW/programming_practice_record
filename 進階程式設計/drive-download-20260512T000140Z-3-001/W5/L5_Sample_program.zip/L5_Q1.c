#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>


int main()
{
    double num[3];
    scanf("%lf,%lf%*[\n\r]", &num[0], &num[1]); 
    num[2] = log2(num[0]) + log2(num[1]); 

    char input[510]; 
    fgets(input, sizeof(input), stdin);

    int i = 0, times = 0, j = 0;
    for (; i < strlen(input); i++) {
        printf("%c", input[i]);

        if (j < 3){
            if (input[i] == '#') {
                times++;
                if (times == 2){
                    if (j < 2){
                        printf("%d", (int)num[j]);
                    }else{
                        printf("%.2lf", num[j]);
                    }
                    j++;
                    times = 0;
                }
            }else{
                times=0;
            }
        }
    }

    return 0;
}
