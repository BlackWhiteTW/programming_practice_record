#include <stdio.h>
#include <string.h>

// For isupper, islower, toupper, and tolower functions
#include <ctype.h> 

int main() {
    char str[1001];
    // Read the input string
    //fgets(str, 1001, stdin);
    if (fgets(str, 1001, stdin) == NULL) {
        fprintf(stderr, "Error reading input\n");
        return 1;
    }


     // Subtract 1 to ignore the newline character
    int len = strlen(str) - 1;

    // Iterate through each character in the string in reverse order
    int i;
    for (i = len - 1; i >= 0; i--) {
        // Check if the character is an alphabet letter6
        if (isalpha(str[i])) { 
            if (isupper(str[i])) {
                // Convert uppercase to lowercase
                printf("%c", tolower(str[i])); 
            } else {
                // Convert lowercase to uppercase
                printf("%c", toupper(str[i])); 
            }
        }
    }

    return 0;
}
