#include<stdio.h>

int main(){
    int n, score, count[11]={0};
    
    while (scanf("%d", &score) && score!=-1){
        if(score>=0 && score<=100){
            count[score/10]++;
        }
    }

    char grade ='A';
    int i;
    for(i = 0; i<=10; i++ ){
        printf("%c_%d\n", grade+i,count[i]);
    }

    return 0;
}