#include <stdio.h>
#include <ctype.h>

int main(){
    char str[1001];
    fgets(str, 1001, stdin);

    int uppercase = 0, lowercase = 0, digits = 0, symbols = 0;

    // Iterate through each character in the string
    int i;
    for (i = 0; str[i] != '\0'; i++) {
        if (isupper(str[i])) {
            uppercase++;
        } else if (islower(str[i])) {
            lowercase++;
        } else if (isdigit(str[i])) {
            digits++;
        } else if (str[i] >= 32 && str[i] <= 126) { // Check for visible symbols
            symbols++;
        }
    }

    // Output the counts
    printf("%d\n%d\n%d\n%d\n", uppercase, lowercase, digits, symbols);

    return 0;
}