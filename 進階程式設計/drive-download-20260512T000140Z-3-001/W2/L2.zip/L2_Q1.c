#include <stdio.h>

void hexToBinary(unsigned int n) {
    int i;
    for (i = 31; i >= 0; i--) {
        printf("%d", (n >> i) & 1);
        if (i % 4 == 0)
            printf(" ");
    }
    printf("\n");
}

int main(){
    int m, i;
    scanf("%d", &m);

    for(i = 0; i < m; i++){
        unsigned int n;
        scanf("%x", &n);
        hexToBinary(n);
    }

    return 0;
}