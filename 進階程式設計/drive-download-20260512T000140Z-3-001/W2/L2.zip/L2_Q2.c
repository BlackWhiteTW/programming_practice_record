#include <stdio.h>

void hexToBinary(unsigned int n) {
    int i;
    for (i = 0; i < 32; i++) {
        printf("%d", (n >> i) & 1); 
        if ((i + 1) % 4 == 0)       
            printf(" ");
    }
    printf("\n");
}

int main() {
    unsigned int m;
    
    while (scanf("%x", &m) && m != -1) {
        hexToBinary(m);
    }
    
    return 0;
}
