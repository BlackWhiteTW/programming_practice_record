#include <stdio.h>
#include <string.h>

void printBinary(char ch) {
    int i;
    for (i = 7; i >= 0; i--) {
        printf("%c", (ch & (1 << i)) ? '1' : '0');
    }
    printf("\n");
}

int main() {
    char str[101];
    fgets(str, 101, stdin); // Read the string, including spaces
    int len = strlen(str);

    int i;
    for (i = 0; i < len; i++) {
        if (str[i] >= 32 && str[i] <= 126) { // Check if the character is a visible character
            printBinary(str[i]);
        }
    }
    return 0;
}
