#include <stdio.h>

void convertToBinary(int n) {
    int binary[32];
    int i = 0;
    int j;

    if(n == 0){
        printf("%d", n);
        printf("\n");
        return;
    }

    while (n > 0) {
        binary[i] = n % 2;
        n = n / 2;
        i++;
    }

    // Pad with zeros to make the length a multiple of 4
    // 用零填充，使長度變成 4 的倍數
    while (i % 4 != 0) {
        binary[i++] = 0;
    }

    // Print the binary number
    // 列印二進制數
    for (j = 0; j < i; j++) {
        printf("%d", binary[j]);
        if ((j + 1) % 4 == 0 && j != i - 1) {
            printf(" ");
        }
    }

    printf("\n");

    /*
    // Print the binary number
    for (int j = 0; j < i; j++) {
        printf("%d", binary[j]);
        if ((j + 1) % 4 == 0 && j != i - 1) {
            printf(" ");
        }
    }
    */   
}

int main() {
    int m;
    scanf("%d", &m);

    int i;
    for (i = 0; i < m; i++) {
        int n;
        scanf("%d", &n);
        convertToBinary(n);
    }
    return 0;
}
