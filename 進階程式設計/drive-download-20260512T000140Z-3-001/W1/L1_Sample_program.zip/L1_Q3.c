#include <stdio.h>

int isPalindrome(int n) {
    int reversed = 0, original = n;
    while (n != 0) {
        reversed = reversed * 10 + n % 10;
        n /= 10;
    }
    return original == reversed;
}

int main() {
    int m;
    while (scanf("%d", &m) && m != -1) {
        if (isPalindrome(m)) {
            printf("YES\n");
        } else {
            printf("NO\n");
        }
    }
    return 0;
}
