#include <stdio.h>

int main() {
    int m, n;
    scanf("%d %d", &m, &n);

    int i, j;
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            printf("$");
        }
        printf("\n");
    }
    return 0;
}
