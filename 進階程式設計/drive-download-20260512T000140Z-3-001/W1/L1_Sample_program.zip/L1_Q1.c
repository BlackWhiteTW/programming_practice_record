#include <stdio.h>
#include <string.h>

int main() {
    char num[21];
    scanf("%20s", num);

    int len = strlen(num);
    int i = len - 1;

    while (i >= 0 && num[i] == '0') {
        i--;
    }

    for (; i >= 0; i--) {
        printf("%c", num[i]);
    }
    printf("\n");

    return 0;
}
