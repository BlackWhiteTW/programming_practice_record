#include <stdio.h>

int isPalindrome(int n) {
    int reversed = 0, original = n;
    while (n != 0) {
        reversed = reversed * 10 + n % 10;
        n /= 10;
    }
    return original == reversed;
}

int main() {
    int m, maxPalindrome = -1;
    scanf("%d", &m);
    
    int i;
    for (i = 0; i < m; i++) {
        int n;
        scanf("%d", &n);
        if (isPalindrome(n) && n > maxPalindrome) {
            maxPalindrome = n;
        }
    }
    if (maxPalindrome == -1) {
        printf("ERROR\n");
    } else {
        printf("%d\n", maxPalindrome);
    }
    return 0;
}
