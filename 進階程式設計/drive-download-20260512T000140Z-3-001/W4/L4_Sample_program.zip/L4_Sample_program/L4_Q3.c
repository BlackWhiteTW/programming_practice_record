#include <stdio.h>
#include <string.h>

#define MAX_INPUT 200

void convertToBase20(unsigned long long n, char *result) {
    if (n == 0) {
        strcpy(result, "0");
        return;
    }
    char digits[] = "0123456789ABCDEFGHIJ";
    int i = 0;
    while (n > 0) {
        result[i++] = digits[n % 20];
        n /= 20;
    }
    result[i] = '\0';
    int j;
    for (j = 0; j < i / 2; j++) {
        char temp = result[j];
        result[j] = result[i - 1 - j];
        result[i - 1 - j] = temp;
    }
}

int main() {
    unsigned long long m[MAX_INPUT];
    char results[MAX_INPUT][20];
    int count = 0;

    char line[256];
    while (fgets(line, sizeof(line), stdin) && line[0] != '-') {
        sscanf(line, "%llu", &m[count]);
        convertToBase20(m[count], results[count]);
        count++;
    }
    int i;
    for (i = 0; i < count; i++) {
        printf("%s\n", results[i]);
    }

    return 0;
}