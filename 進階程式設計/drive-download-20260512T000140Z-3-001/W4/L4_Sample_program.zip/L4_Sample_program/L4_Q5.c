#include <stdio.h>
#include <string.h>
#include <math.h>

#define MAX 2000000

void sieveOfEratosthenes(int prime[], int n) {
    memset(prime, 1, sizeof(int) * (n + 1));
    prime[0] = prime[1] = 0;
    int p, i;
    for (p = 2; p * p <= n; p++) {
        if (prime[p]) {
            for (i = p * p; i <= n; i += p) {
                prime[i] = 0;
            }
        }
    }
}

int main() {
    int prime[MAX];
    sieveOfEratosthenes(prime, MAX - 1);

    int m, n;
    while (scanf("%d %d", &m, &n) && m != -1) {
        int count = 0;
        int i;
        for (i = m; i <= n; i++) {
            if (prime[i]) {
                count++;
            }
        }
        printf("%d\n", count);
    }

    return 0;
}
