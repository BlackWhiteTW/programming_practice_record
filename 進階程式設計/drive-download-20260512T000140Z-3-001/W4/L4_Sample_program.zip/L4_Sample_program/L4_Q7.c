#include <stdio.h>
#include <math.h>

int main() {
    int i, k;
    scanf("%d", &k);

    double finalAreas[k];

    for (i = 0; i < k; i++) {
        int areaA, areaB;
        scanf("%d %d", &areaA, &areaB);
        
        if (areaA > areaB){
            int c;
            c = areaA;
            areaA = areaB;
            areaB = c;
        }

        double a = sqrt(areaA);
        double b = sqrt(areaB);        
        double x =  (a * b) / (a + b);
        double shadowArea = a * x / 2;
        finalAreas[i] = round(shadowArea * 100) / 100;
    }

    for (i = 0; i < k; i++) {
        printf("%.2f\n", finalAreas[i]);
    }

    return 0;
}
