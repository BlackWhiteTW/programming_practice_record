#include <stdio.h>

int isLeapYear(int year) {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

int main() {
    int m, n, count = 0;
    scanf("%d %d", &m, &n);
    int year;
    for (year = m; year <= n; year++) {
        if (isLeapYear(year)) {
            count++;
        }
    }
    printf("%d\n", count);
    return 0;
}
