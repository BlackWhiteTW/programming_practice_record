#include <stdio.h>

int main() {
    int m, n;
    scanf("%d %d", &m, &n);

    if (m > n) {
        printf("Fail\n");
    } else {
        int change = n - m;
        int denominations[] = {2000, 1000, 500, 100, 50, 10, 5, 1};
        int i;
        for (i = 0; i < 8; i++) {
            printf("%d\n", change / denominations[i]);
            change %= denominations[i];
        }
    }

    return 0;
}
