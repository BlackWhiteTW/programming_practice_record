#include <stdio.h>
#include <math.h>

int main() {
    int k;
    scanf("%d", &k);
    while (k--) {
        int x2, a;
        scanf("%d %d", &x2, &a);
        float x = sqrt(x2);
        float shadowArea = (a * ( x*a/(a+x)))/2;
        float finalArea = round(shadowArea*100) /100;
        printf("%.2f\n", finalArea);
    }
    return 0;
}
