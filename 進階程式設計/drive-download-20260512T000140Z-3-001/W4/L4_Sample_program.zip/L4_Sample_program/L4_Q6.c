#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    char *game = (char *)malloc(2001 * sizeof(char));
    if (game == NULL) {
        printf("Memory allocation failed\n");
        return 1;
    }

    scanf("%2000s", game);
    int len = strlen(game);
    int mingWins = 0, ciWins = 0, ties = 0, i;

    for (i = 0; i < len; i += 2) {
        char ming = game[i];
        char ci = game[i + 1];

        if (ming == ci) {
            ties++;
        } else if ((ming == 'V' && ci == '#') || (ming == '@' && ci == 'V') || (ming == '#' && ci == '@')) {
            mingWins++;
        } else {
            ciWins++;
        }
    }

    printf("%d\n%d\n%d\n", mingWins, ciWins, ties);

    if (mingWins > ciWins) {
        printf("%.1f\n", mingWins * 100.0 / (mingWins + ciWins + ties));
    } else {
        printf("%.1f\n", ciWins * 100.0 / (mingWins + ciWins + ties));
    }

    free(game);
    return 0;
}
