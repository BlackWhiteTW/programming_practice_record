#include <stdio.h>
#include <string.h>
#include <math.h>

unsigned long long reverseNumber(unsigned long long n) {
    unsigned long long reversed = 0;
    while (n != 0) {
        reversed = reversed * 10 + n % 10;
        n /= 10;
    }
    return reversed;
}

int main() {
    char ball[4];
    unsigned long long int score = 0;
    int firstRound = 1;

    while (scanf("%s", ball) != EOF) {
        if (strcmp(ball, "###") == 0) {
            if (firstRound) {
                score = 10000000000ULL;
            }
            break;
        }

        unsigned long long int number;
        scanf("%llu", &number);

        switch (ball[0]) {
            case 'B':
                score += number;
                break;
            case 'Y':
                score += reverseNumber(number);
                break;
            case 'R':
                score *= (unsigned long long)pow(2, number);
                break;
            case 'G':
                score /= (unsigned long long)pow(2, number);
                break;
            default:
                break;
        }
        firstRound = 0;
    }

    printf("%llu\n", score);
    return 0;
}
