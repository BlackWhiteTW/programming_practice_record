#include <stdio.h>
#include <math.h>

int main() {
    int k, i;
    double x, R;

    scanf("%d", &k);

    for ( i=0; i<k; i++){
        // 讀取邊長x
        scanf("%lf", &x);
        // 計算外接圓半徑
        R = x / (2 * sin(45 * M_PI / 180));
        // 输出结果
        printf("%.2lf\n", R);
    }
    return 0;
}
