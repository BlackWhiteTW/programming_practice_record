#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h> //atoi

// 定義一個函數用來從方程式中提取對應於主對角線元素的係數
int extractCoefficient(const char* equation, int index) {
    char coeffStr[10] = {0}, temp; // 用來存放係數字串的緩衝區
    int i = 0, coeff = 0, start = 0, end;

    // 遍歷字符串以找到x的係數
    while (equation[i] != '\0') {
        if (equation[i] == 'x') {
            int number = 0;
            int j = i + 1;

            // 建立跟在'x'後面的數字
            while (isdigit(equation[j])) {
                number = number * 10 + (equation[j] - '0');
                j++;
            }

            // 如果這個x對應於我們的對角線，提取它的係數
            if (number == index) {
                int k = i - 1;
                int sign = 1;
                int coeffIndex = 0;

                // 往回走捕捉完整的係數
                while (k >= 0 && (isdigit(equation[k]) || equation[k] == '-')) {
                    if (equation[k] == '-') {
                        sign = -1; // 如果係數前面有減號，改變符號
                        break;
                    }
                    coeffStr[coeffIndex++] = equation[k]; // 將係數加入到緩衝區
                    k--;
                }

                // 由於係數是反向捕捉的，所以現在要將它們反轉回來
                for (start = 0, end = coeffIndex - 1; start < end; start++, end--) {
                    temp = coeffStr[start];
                    coeffStr[start] = coeffStr[end];
                    coeffStr[end] = temp;
                }

                // 將係數字符串轉換為整數
                coeff = atoi(coeffStr) * sign;
                break;
            } else {
                // 如果不是我們感興趣的x，則跳過這部分
                i = j;
            }
        } else {
            i++;
        }
    }

    return coeff; // 返回提取到的係數
}

int main() {
    char line[1024]; // 存放每一行輸入的字符串
    int trace = 0, row = 1; // trace用來存儲跡，row表示當前處理的行數

    // 讀取輸入直到遇到"###"
    while (fgets(line, sizeof(line), stdin)) {
        if (strcmp(line, "###\n") == 0) {
            break; // 如果讀到"###"，終止循環
        }

        // 累加主對角線元素的係數到跡
        trace += extractCoefficient(line, row);
        row++; // 處理下一行
    }

    // 輸出矩陣的跡
    printf("%d\n", trace);
    return 0;
}
