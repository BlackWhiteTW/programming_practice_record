#include <stdio.h>
#include <string.h>
#include <ctype.h>

void bubbleSort(char arr[], int n) {
    int i, j;
    for (i = 0; i < n-1; i++) {
        for (j = 0; j < n-i-1; j++) {
            if (arr[j] > arr[j+1]) {
                char temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }
}

int main() {
    char input[501], lowercase[501], uppercase[501];
    int lowercaseCount = 0, uppercaseCount = 0, i;
    fgets(input, 501, stdin);

    for (i = 0; i < strlen(input); i++) {
        if (islower(input[i])) {
            lowercase[lowercaseCount++] = input[i];
        } else if (isupper(input[i])) {
            uppercase[uppercaseCount++] = input[i];
        }
    }

    bubbleSort(lowercase, lowercaseCount);
    for (i = 0; i < lowercaseCount; i++) {
        printf("%c", lowercase[i]);
    }

    bubbleSort(uppercase, uppercaseCount);
    for (i = 0; i < uppercaseCount; i++) {
        printf("%c", uppercase[i]);
    }
    printf("\n");

    return 0;
}
