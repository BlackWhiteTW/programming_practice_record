#include <stdio.h> 
#include <stdlib.h> 

// 自訂比較函數，用於排序
int compare(const void *a, const void *b) { 
    // 將 void 指標轉型為 int 指標，然後取其指向的值
    int num1 = *(const int *)a; 
    int num2 = *(const int *)b; 
      
    // 分別計算兩個數字的百位、十位和個位數字
    int hundredsDigit1 = num1 / 100; 
    int tensDigit1 = (num1 / 10) % 10; 
    int unitsDigit1 = num1 % 10; 
      
    int hundredsDigit2 = num2 / 100; 
    int tensDigit2 = (num2 / 10) % 10; 
    int unitsDigit2 = num2 % 10; 
      
    // 依照題目要求的排序規則進行比較
    if (hundredsDigit1 != hundredsDigit2) {
        return hundredsDigit1 - hundredsDigit2;  // 先比較百位數
    } else if (tensDigit1 != tensDigit2) { 
        return tensDigit2 - tensDigit1;  // 百位數相同，比較十位數
    } else {
        // 十位數也相同，比較個位數，且偶數優先於奇數
        if (unitsDigit1 % 2 == 0 && unitsDigit2 % 2 != 0) {
            return -1;  // num1 的個位數為偶數，num2 為奇數，num1 排在前
        } else if (unitsDigit1 % 2 != 0 && unitsDigit2 % 2 == 0) {
            return 1;   // num1 的個位數為奇數，num2 為偶數，num2 排在前
        } else {
            // 兩個數字的個位數都是偶數或都是奇數，按數值大小排序
            return unitsDigit1 - unitsDigit2;
        }
    }
} 

int main() { 
    int num, i; 
    scanf("%d", &num);  // 讀取數字個數
      
    int numbers[num]; 
    for (i = 0; i < num; i++) {
        scanf("%d,", &numbers[i]);  // 讀取每個數字，注意逗號
    }
    
    qsort(numbers, num, sizeof(int), compare);  // 使用快速排序函數對數字進行排序

    // 輸出排序後的結果
    for (i = 0; i < num; i++) {
        if (i != 0) {
            printf(",");  // 在數字之間加上逗號
        }
        printf("%d", numbers[i]); 
    }
        
    return 0; 
}
