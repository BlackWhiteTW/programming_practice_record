#include <stdio.h>
#include <math.h>
#include <float.h>

#define pi 3.141


double area(double sidelen){
    double squarearea, circlearea;
    squarearea = sidelen * sidelen;
    circlearea = pi * sidelen * sidelen / 4;
    return squarearea - circlearea;
}

int main(){
    int num, i;
    double sidelen, shadowarea;
    scanf("%d", &num);

    for (i = 0; i < num; i++) {
        scanf("%lf", &sidelen);

        shadowarea = area(sidelen);
        shadowarea = round(shadowarea*100 + 0.001) / 100.0;
        printf("%.2f\n", shadowarea);
    }

    return 0;
}
